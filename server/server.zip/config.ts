process.env.MYSQL_HOST = 'mysql.stud.ntnu.no';
process.env.MYSQL_USER = 'rubenvb_todo';
process.env.MYSQL_PASSWORD = 'rubenvb_todo_pass';
process.env.MYSQL_DATABASE = 'rubenvb_todo_dev';